-- ============================================================
-- A GRANDE EXPEDIÇÃO — Setup do banco de dados no Supabase
-- ------------------------------------------------------------
-- Cole este script inteiro no Supabase → SQL Editor → New query
-- e clique em RUN. Ele cria todas as tabelas necessárias.
-- Seguro para rodar mais de uma vez (usa IF NOT EXISTS).
-- ============================================================

CREATE TABLE IF NOT EXISTS "players" (
  "id" serial PRIMARY KEY NOT NULL,
  "name" text NOT NULL,
  "patrol" text NOT NULL,
  "points" integer DEFAULT 0 NOT NULL,
  "level" integer DEFAULT 1 NOT NULL,
  "streak" integer DEFAULT 0 NOT NULL,
  "created_at" timestamp DEFAULT now() NOT NULL,
  "updated_at" timestamp DEFAULT now() NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS "players_name_patrol_idx"
  ON "players" USING btree ("name", "patrol");

CREATE TABLE IF NOT EXISTS "achievements" (
  "id" serial PRIMARY KEY NOT NULL,
  "player_id" integer NOT NULL,
  "code" text NOT NULL,
  "created_at" timestamp DEFAULT now() NOT NULL
);

CREATE TABLE IF NOT EXISTS "progress" (
  "id" serial PRIMARY KEY NOT NULL,
  "player_id" integer NOT NULL,
  "territory" text NOT NULL,
  "completed" integer DEFAULT 0 NOT NULL,
  "correct" integer DEFAULT 0 NOT NULL,
  "total" integer DEFAULT 0 NOT NULL,
  "meta" jsonb,
  "updated_at" timestamp DEFAULT now() NOT NULL
);

-- Índices auxiliares para consultas de ranking/progresso
CREATE INDEX IF NOT EXISTS "players_points_idx" ON "players" ("points" DESC);
CREATE INDEX IF NOT EXISTS "achievements_player_idx" ON "achievements" ("player_id");
CREATE INDEX IF NOT EXISTS "progress_player_idx" ON "progress" ("player_id");
