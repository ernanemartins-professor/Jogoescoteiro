import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";

/**
 * Conexão de banco de dados pronta para Supabase + Vercel.
 *
 * No Vercel (serverless), use a "Connection Pooling" string do Supabase
 * (porta 6543, modo transaction / pgbouncer). Localmente você pode usar a
 * conexão direta (porta 5432).
 *
 * Variáveis de ambiente aceitas (a primeira encontrada é usada):
 *  - DATABASE_URL            (recomendada)
 *  - POSTGRES_URL            (padrão da integração Vercel/Supabase)
 *  - POSTGRES_PRISMA_URL
 */
function resolveConnectionString(): string | undefined {
  return (
    process.env.DATABASE_URL ||
    process.env.POSTGRES_URL ||
    process.env.POSTGRES_PRISMA_URL ||
    undefined
  );
}

const connectionString = resolveConnectionString();

// Supabase exige SSL. Em produção (Vercel) forçamos SSL; localmente
// mantemos desabilitado para o Postgres do sandbox/dev.
function shouldUseSsl(url: string | undefined): boolean {
  if (!url) return false;
  if (/sslmode=disable/i.test(url)) return false;
  // Hosts do Supabase ou qualquer conexão remota (não-localhost) usam SSL.
  const isLocal = /(localhost|127\.0\.0\.1)/i.test(url);
  if (/supabase\.(co|com)/i.test(url)) return true;
  if (/sslmode=require/i.test(url)) return true;
  return !isLocal;
}

const globalForDb = globalThis as typeof globalThis & {
  __grandeExpedicaoPool?: Pool;
};

function createPool(): Pool {
  if (!connectionString) {
    throw new Error(
      "DATABASE_URL (ou POSTGRES_URL) não configurada. Configure a variável de ambiente com a connection string do Supabase.",
    );
  }
  return new Pool({
    connectionString,
    ssl: shouldUseSsl(connectionString) ? { rejectUnauthorized: false } : undefined,
    // Limites conservadores para ambiente serverless (Vercel + pgbouncer).
    max: 5,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 15_000,
  });
}

export const pool = globalForDb.__grandeExpedicaoPool ?? createPool();

if (process.env.NODE_ENV !== "production") {
  globalForDb.__grandeExpedicaoPool = pool;
}

export const db = drizzle(pool, { schema });
