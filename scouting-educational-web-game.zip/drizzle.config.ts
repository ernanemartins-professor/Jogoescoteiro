import "dotenv/config";
import type { Config } from "drizzle-kit";

// Usa DATABASE_URL/POSTGRES_URL (Supabase) quando disponível; caso contrário,
// cai para o Postgres local do ambiente de desenvolvimento.
const url =
  process.env.DATABASE_URL ||
  process.env.POSTGRES_URL ||
  "postgresql://postgres:postgres@127.0.0.1:5432/app_db";

export default {
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  out: "./drizzle",
  dbCredentials: {
    url,
    // Supabase requer SSL. Para conexões locais isso é ignorado.
    ssl: /supabase\.(co|com)/i.test(url) ? { rejectUnauthorized: false } : undefined,
  },
} satisfies Config;
