# 🏕️ A GRANDE EXPEDIÇÃO

Jogo online educativo para escoteiros — **Conhecimento · Aventura · Desafio · Espírito Escoteiro**.

- 4 patrulhas: 🐆 Pantera · 🦜 Arara Azul · ⭐ Cruzeiro do Sul · 🦁 Leão
- 10 territórios de conhecimento + missões narrativas
- Mais de **1000 perguntas** (a alternativa correta muda de lugar a cada rodada)
- Pontuação individual que soma para a patrulha
- Ranking ao vivo (patrulhas e escoteiros), níveis e medalhas

Stack: **Next.js (App Router)** + **Drizzle ORM** + **PostgreSQL (Supabase)**, pronto para **Vercel**.

---

## 🚀 Deploy no Vercel com Supabase (passo a passo)

### 1) Criar o banco no Supabase
1. Acesse [supabase.com](https://supabase.com) → **New project**.
2. Defina uma senha para o banco (guarde-a).
3. Após criar, vá em **SQL Editor → New query**, cole o conteúdo de
   [`supabase/setup.sql`](./supabase/setup.sql) e clique em **RUN**.
   Isso cria as tabelas `players`, `achievements` e `progress`.

### 2) Pegar a connection string
No Supabase: **Project Settings → Database → Connection string**.

- Para o **Vercel (serverless)** use a opção **Connection pooling → Transaction**
  (porta **6543**). Ela fica parecida com:
  ```
  postgresql://postgres.<ref>:SUA_SENHA@aws-0-<regiao>.pooler.supabase.com:6543/postgres?sslmode=require
  ```
  Troque `SUA_SENHA` pela senha do banco. Mantenha `?sslmode=require`.

### 3) Publicar no Vercel
1. Suba este repositório para o GitHub.
2. No [vercel.com](https://vercel.com) → **Add New → Project** → importe o repositório.
3. Em **Environment Variables**, adicione:

   | Nome           | Valor                                             |
   | -------------- | ------------------------------------------------- |
   | `DATABASE_URL` | a connection string **pooler (6543)** do Supabase |

4. Clique em **Deploy**. Pronto! 🎉

O `next.config` e a camada de banco já habilitam **SSL automaticamente** para
o Supabase, então não é preciso configurar mais nada.

---

## 💻 Rodando localmente

```bash
# 1. Instale as dependências
npm install

# 2. Crie o arquivo .env (baseado no exemplo) e cole sua DATABASE_URL
cp .env.example .env

# 3. Crie as tabelas no banco (uma vez)
npm run db:push

# 4. Suba o servidor de desenvolvimento
npm run dev
```

Acesse http://localhost:3000

### Scripts úteis
| Script               | O que faz                                    |
| -------------------- | -------------------------------------------- |
| `npm run dev`        | Servidor de desenvolvimento                  |
| `npm run build`      | Build de produção                            |
| `npm run start`      | Servir o build de produção                   |
| `npm run db:push`    | Aplica o schema no banco (Drizzle)           |
| `npm run db:studio`  | Abre o Drizzle Studio para inspecionar dados |

> Dica: para `db:push` você pode usar a conexão **direta** (porta 5432) do
> Supabase em `DATABASE_URL`, que costuma ser mais estável para migrações.

---

## 🗂️ Estrutura

```
src/
├── app/
│   ├── page.tsx              # Tela inicial (nome + patrulha)
│   ├── mapa/                 # Mapa da expedição (10 territórios)
│   ├── jogo/[territory]/     # Quiz de cada território
│   ├── missoes/              # Missões narrativas
│   ├── ranking/              # Ranking ao vivo
│   ├── medalhas/             # Conquistas e níveis
│   ├── instrucoes/           # Como jogar
│   └── api/                  # player, score, ranking, questions, medals, health
├── components/Hud.tsx        # Barra de status do jogador
├── db/                       # Conexão (Supabase-ready) + schema Drizzle
└── lib/                      # Banco de perguntas, missões, dados do jogo
supabase/setup.sql            # Script de criação das tabelas
```

---

## ⚙️ Variáveis de ambiente

| Variável       | Obrigatória | Descrição                                             |
| -------------- | :---------: | ----------------------------------------------------- |
| `DATABASE_URL` |     Sim     | Connection string do Postgres/Supabase (com `sslmode=require`) |

Também são aceitas `POSTGRES_URL` / `POSTGRES_PRISMA_URL` (criadas
automaticamente pela integração oficial Vercel + Supabase).

---

Feito com ⚜️ para o Movimento Escoteiro.
